import socket
import sys
import os

whitelist = [d.strip() for d in "*".split(",")]
original_getaddrinfo = socket.getaddrinfo

def custom_getaddrinfo(host, port, *args, **kwargs):
    if "*" not in whitelist:
        if not any(host == d or host.endswith("." + d) for d in whitelist if d):
            raise socket.gaierror(f"Security Alert: Domain '{host}' is not in the configured proxy whitelist.")
    return original_getaddrinfo(host, port, *args, **kwargs)

socket.getaddrinfo = custom_getaddrinfo

if __name__ == '__main__':
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        code = f.read()
    sys.argv.pop(0)
    exec(code, {"__name__": "__main__", "__file__": sys.argv[0]})
